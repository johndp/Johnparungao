$(window).scroll(function(){

    var sCount = $(this).scrollTop();
    $('#scrollCounter').html(sCount);
    
    $('.logo').css({
        'transform' : 'translate(0px, ' + sCount  / 5 + '%)'
    });

    $('.logo-shadow').css({
        'transform' : 'translate(0px, ' + sCount  / 3 + '%)'
    });

    $('.object').css({
        'transform' : 'translate(0px, -' + sCount  / 20 + '%)'
    });


    if( $('.description').offset().top - $(window).height() / 3 < sCount) {

    $('.description').addClass('description-is-showing')
    };

    if( sCount > $('.gallery').offset().top - ( $(window).height() / 2) ){
        $('.gallery figure').each(function(i){
            setTimeout(function(){
                $('.gallery figure').eq(i).addClass('is-showing')
            }, 200 * (i+1));

        });

    }

    


});